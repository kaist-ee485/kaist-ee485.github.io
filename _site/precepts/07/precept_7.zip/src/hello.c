/*--------------------------------------------------------------------*/
/* hello.c                                                            */
/*--------------------------------------------------------------------*/

#include <stdio.h>

/* Write "hello, world\n" to stdout.  Return 0. */
int main(void)
{
	printf("hello, world\n");
	return 0;
}

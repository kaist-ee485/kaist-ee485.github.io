/*--------------------------------------------------------------------*/
/* testdynarray.c                                                     */
/* Author: Bob Dondero                                                */
/* Modified by Younghwan Go                                           */
/*--------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "dynarray.h"

int main(int argc, char *argv[])
{
	DynArray_T oDynArray;
	int numElements, i;

	/* Check input argument. */
	if (argc != 2) {
		fprintf(stderr, "Usage: %s <num elements>\n", argv[0]);
		exit(-1);
	}

	/* Create new DynArray. */
	oDynArray = DynArray_new(0);
	if (oDynArray == NULL) exit(EXIT_FAILURE);

	/* Add elements into DynArray. */
	numElements = atoi(argv[1]);
	printf("Adding %d elements into DynArray\n", numElements);
	for (i = 0; i < numElements; i++) {
		int *pi = malloc(sizeof(int));
		assert(pi);
		*pi = i;

		if (!DynArray_add(oDynArray, pi)) 
			exit(EXIT_FAILURE);
	}

	/* Remove elements from DynArray. */
	printf("Removing %d elements from DynArray\n", numElements);
	for (i = 0; i < numElements; i++) {
		int *pi = DynArray_removeAt(oDynArray, 0);
		free(pi);
	}
	
	/* Demonstrate DynArray_free. */
	DynArray_free(oDynArray);
	
	return 0;
}
